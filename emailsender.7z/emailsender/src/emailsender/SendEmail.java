package emailsender;


import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail {

   public static void main(String [] args) {    
      // Recipient's email ID needs to be mentioned.
      String to = "ramarbalasubramanian@gmail.com";

      // Sender's email ID needs to be mentioned
      String from = "ramarbalasubramanian@gmail.com";

      // Assuming you are sending email from localhost
      String host = "localhost";

      // Get system properties
      Properties properties = System.getProperties();
      System.setProperty("java.net.preferIPv4Stack", "true");
      // Setup mail server
      properties.setProperty("mail.smtp.host","smtp.gmail.com");
      properties.setProperty("mail.smtp.port","587");
      properties.setProperty("mail.from", "ramarbalasubramanian@gmail.com");
      properties.setProperty("mail.smtp.starttls.enable", "true" );
      properties.setProperty("mail.smtp.socketFactory.port", "587");
      
      //properties.setProperty("mail.smtp.user", "ramarbalasubramanian");
      //properties.setProperty("mail.smtp.password", "");
      Authenticator pas = new SMTPAuthenticator("ramarbalasubramanian@gmail.com", "");
      properties.setProperty("mail.smtp.auth", "true"); 

      // Get the default Session object.
      Session session = Session.getInstance(properties,pas);

      try {
         // Create a default MimeMessage object.
         MimeMessage message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         // Set To: header field of the header.
         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
         message.addRecipient(Message.RecipientType.CC, new InternetAddress("subramanian.ramar@globallogic.com"));

         
         InternetAddress[] addressTo = new InternetAddress[1];
         addressTo[0] = new InternetAddress("ramarbalasubramanian@gmail.com");
         /*addressTo[1] = new InternetAddress("subramanian.ramar@globallogic.com");
         addressTo[2] = new InternetAddress("xx@xx.cvmbsk");
         addressTo[3] = new InternetAddress("mohan.eswaran@globallogic.com");*/
         message.setRecipients(Message.RecipientType.TO, addressTo);
         
         
         // Set Subject: header field
         message.setSubject("This is the Subject Line!");

         // Now set the actual message
         message.setText("This is actual message");

         // Send message
         Transport.send(message);
         System.out.println("Sent message successfully....");
      } catch ( Exception mex) {
         mex.printStackTrace();
      }
   }
   
   
   
   private static class SMTPAuthenticator extends javax.mail.Authenticator
   {
       private String _user;
       private String _password;
       
       public SMTPAuthenticator(String pUser, String pPassword)
       {
           _user = pUser;
           _password = pPassword;
       }
       
       public PasswordAuthentication getPasswordAuthentication()
       {
           return new PasswordAuthentication(_user, _password);
       }
   }
}

